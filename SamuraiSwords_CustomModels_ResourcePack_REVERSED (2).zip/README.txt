SamuraiSwords — пользовательский ресурс-пак

Маппинг:
ronin.png        = 6 — Меч Ронина
samurai.png      = 5 — Меч Самурая
bushido.png      = 4 — Меч Бусидо
daime.png        = 3 — Меч Дайме
shogun.png       = 2 — Катана Сёгуна
true_shogun.png  = 1 — Истинная Катана Сёгуна

Первые два файла имеют размер 32x160 и распознаны как 5 кадров по 32x32; для них включена анимация.

Для Minecraft 1.21.11 используются:
assets/samuraiswords/items/*.json
assets/samuraiswords/models/item/*.json
assets/samuraiswords/textures/item/*.png

Если сервер должен автоматически отправлять пак игрокам, укажи прямой HTTPS URL ZIP в config.yml -> resource-pack.url.
